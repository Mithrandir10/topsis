from sys import version
from setuptools import _install_setup_requires, setup

setup(name='topsis',version='0.1',packages=['topsis'],install_requires=['pandas','numpy'])